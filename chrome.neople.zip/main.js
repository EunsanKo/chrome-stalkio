function run() {
  	

	
	var scrollheight = 40;

	

	var ajax = function(options, callback) {
	  var xhr;
	  xhr = new XMLHttpRequest();
	  xhr.open(options.type, options.url, options.async || true);
	  xhr.onreadystatechange = function() {
	    if (xhr.readyState === 4) {
	      return callback(xhr.responseText);
	    }
	  };
	  return xhr.send();
	};


	var $topic8 = $( "#topic8" );
	var $topic11 = $( "#topic11" );
	var $topic14 = $( "#topic14" );
	var $topic17 = $( "#topic17" );
	var $topic20 = $( "#topic20" );
	var $topicall = $( "#topic23" );

	
	var callAjax = function(target,callback){
		ajax({type:"GET", url:target},function(result){
			result = result.replace(/img/gi,'div');
			callback(result);
		});
	}

	var topic_url ="http://n.search.naver.com/jsonp/hottopic.js?_callback=calbackHotTopic&hour=";
    var search = "http://search.naver.com/search.naver?where=nexearch&query=&sm=top_hty&fbm=0&ie=utf8";
    var contentWindow = document.getElementById('theFrame').contentWindow;
	var callHotTopic = function(hour){
		

		ajax({type:"GET", url:topic_url+hour},function(result){
			

			var message = {

		      command: hour,
		      result: result,
		    };
			contentWindow.postMessage(message,'*');
			//setTimeout(result,100);
		});

	};

	var callCategoryTopic = function(){
		ajax({type:"GET", url:search},function(result){
			result = result.replace(/img/gi,'div');
			var script = $(result).find('div#sub_pack.sub_pack').find("script[type='text/javascript']:contains('aKwds')");
			
			var message = {
			  
		      command: 'category',
		      result: script.html(),
		    };
			contentWindow.postMessage(message,'*');
		});

		
	}
	

	  // on result from sandboxed frame:
  	window.addEventListener('message', function(event) {
  		var time = event.data.time;
  		var html = event.data.result;

  		if(time=='category'){
  			categoryParsing(html);
  		}else{
  			hotTopicParsing(time, html);	
  		}

  		
  		
	});
	
  	var categoryParsing = function(categorys){
  		console.log(categorys);
  		for(var i in categorys){
  			
  			var cate = categorys[i]
  			var code = cate.code;

  			var timeTitle = "<span class='label label-primary'>"+cateObj[code]+"</span>";
			var innerhtml="" 
			$.each(cate.keywords,function(inx,val){
				var arrow = cate.percent[inx];
		      	var point = inx+1;
		      	var link = "http://search.naver.com/search.naver?where=nexearch&sm=tab_bck&ie=utf8&ug_cid="+code+"&query="+encodeURIComponent(val);
		      	var title = val;
		      	
		      	title = point+"&nbsp;&nbsp;&nbsp;"+(point==1?'<strong>'+title+'</strong>':title)+"";

		      	var temphtml = "";

		      	temphtml += "<span class='badge alert-danger'  style='margin:-5px -10px'>"+arrow+"</span>";

		      	innerhtml += "<li  class='issue_list_wrap list-group-item' style='border:1px solid #17A91E'>"+temphtml+"<p class='ellip fulltitle' style='margin:0 0 0 -12px;width:130px;position:absolute;top:5px;font-size: smaller'><a href="+link+" target='_blank' class='' >"+title+"</a></p>"

			});
			$( "#category_"+code ).html(timeTitle);
			$( "#category_content_"+code ).html(innerhtml);
  		}
  	}

  	var cateObj = {
  		"sgm":"싱글남",
  		"sgf":"싱글녀",
  		"mwk":"직장인",
  		"hwf":"주부",
  		"uni":"대학생",
  		"tee":"청소년",

  	}

	var hotTopicParsing = function(time, html){
		var hotTopicList = $(html).find('li').find('a');

		
		
		var dataTime = $(html).find('time').html();
		
		var innerhtml="" 
		var timeTitle = hotTopicList.length>0?"<span class='label label-primary'>"+dataTime+"</span>":"<span class='label label-danger'>"+timeObj[time]+"</span>";
		


		if(hotTopicList.length==0){
			innerhtml += "<li  class='issue_list_wrap list-group-item' style='border:1px solid #17A91E'><p class='ellip fulltitle' style='margin:0 0 0 -12px;width:130px;position:absolute;top:5px;font-size: smaller'>"+getLeftTime(time);+"</p>"
		}
		$.each(hotTopicList,function(inx,val){
			var arrow = $(val).find('.rank.new').find('span:not(.spim)').html();
	      	var point = $(val).find('.num').html();
	      	var link = $(val).attr('href');
	      	var title = $(val).find('.tit').html();
	      	
	      	title = point+"&nbsp;&nbsp;&nbsp;"+(point==1?'<strong>'+title+'</strong>':title)+"";

	      	var temphtml = "";

	      	if(arrow) temphtml += "<span class='badge alert-danger'  style='margin:-5px -10px'>N</span>";

	      	innerhtml += "<li  class='issue_list_wrap list-group-item' style='border:1px solid #17A91E'>"+temphtml+"<p class='ellip fulltitle' style='margin:0 0 0 -12px;width:130px;position:absolute;top:5px;font-size: smaller'><a href="+link+" target='_blank' class='' >"+title+"</a></p>"

		});
		$( "#title"+time ).html(timeTitle);
		$( "#topic"+time ).html(innerhtml);
		//$('.fulltitle').tooltip(); 

		

		
	}
	
	var timeObj = {
		8:'8:00 Topic',
		11:'11:00 Topic',
		14:'14:00 Topic',
		17:'17:00 Topic',
		20:'20:00 Topic',
		23:'23:00 Topic'
	}

  	

	function getDay(t){
		var d = new Date();
		return d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate()+" "+(t==undefined?d.getHours():t)+":"+(t==undefined?d.getMinutes():'00')+":"+(t==undefined?d.getSeconds():'00');
	}

	function getLeftTime(t){
		var current = getDay();
		var timeTitle = getDay(t);
		
		var cd = new Date(current);

		var td = new Date(timeTitle);
		
		var timeGap = Math.floor((td.getTime()-cd.getTime()) / (1000 * 60  ));
		
		var h = Math.floor(timeGap/60);
		var m = timeGap%60;
		
		return (h+"시간 "+m+" 분 남았습니다");
		
	}

	function sync(){

		$('#synctime').html(" @ "+getDay());

		callHotTopic(8);
	  	callHotTopic(11);
	  	callHotTopic(14);
	  	callHotTopic(17);
	  	callHotTopic(20);
		callHotTopic(23);
		
	};



	sync();
	callCategoryTopic();
	var naver = function(result){
	  	
	  	
	  	
		var rankList = $(result).find('.rankup').find('li:not(#lastrank)').find('a');

	    var innerhtml = "";
	    $.each(rankList,function(inx,val){
	      
	      var arrow = $(val).find('.tx').html();
	      var point = $(val).find('.rk').html();
	      var link = $(val).attr('href');
	      var title = $(val).attr('title');
	      title = (inx+1)+"&nbsp;&nbsp;&nbsp;"+(inx==0?'<strong>'+title+'</strong>':title)+""
	      var temphtml = "";
	      
	   
	      if(arrow=="상승"){
	        temphtml += "<span class='badge alert-danger'><i class='glyphicon glyphicon-arrow-up'></i>  "+point+"</span>";
	      }else if(arrow=="New"){
	        temphtml += "<span class='badge alert-danger'>  NEW</span>";
	      }else if(arrow=="하락"){
	        temphtml += "<span class='badge alert-info'><i class='glyphicon glyphicon-arrow-down'></i>  "+point+"</span>";
	      }else{
	        temphtml += "<span class='badge alert-success'><i class='glyphicon glyphicon-minus'></i>  "+point+"</span>";
	      }
	      
	      innerhtml += "<li  class='issue_list_wrap list-group-item' style='border:1px solid #17A91E'>"+temphtml+"<p class='ellip' style='width:140px;position:absolute;top:10px;font-size: smaller;'><a href="+link+" target='_blank' class='' >"+title+"</a></p><p class='ellip' style='width:140px;position:absolute;top:80px'><a href="+link+"target='_blank'  class='' >"+title+"</a></p></li>"

	      if(inx==9){
	        $log.html("<ul class='list-group'>"+innerhtml+"</ul>");
	        scrolltextup('log',900);
	      }
	    }); 
		
	}

	var short_naver = function(result){
		var rankList = $(result).find('.rankup').find('li:not(#lastrank)').find('a');

		var shortInnerhtml=""
		$.each(rankList,function(inx,val){
	      
	      var arrow = $(val).find('.tx').html();
	      var point = $(val).find('.rk').html();
	      var link = $(val).attr('href');
	      var title = $(val).attr('title');
	      title = (inx+1)+"&nbsp;&nbsp;&nbsp;"+(inx==0?'<strong>'+title+'</strong>':title)+""
	      var temphtml = "";
	      if(arrow=="상승"){
	        temphtml += "<span class='badge alert-danger' style='float: right;'><i class='glyphicon glyphicon-arrow-up'></i>  "+point+"</span>";
	      }else if(arrow=="New"){
	        temphtml += "<span class='badge alert-danger' style='float: right;'>  NEW</span>";
	      }else if(arrow=="하락"){
	        temphtml += "<span class='badge alert-info' style='float: right;' class='glyphicon glyphicon-arrow-down'></i>  "+point+"</span>";
	      }else{
	        temphtml += "<span class='badge alert-success' style='float: right;'><i class='glyphicon glyphicon-minus'></i>  "+point+"</span>";
	      }
	   		      
	      shortInnerhtml += "<p class='ellip' style='width:200px;position:absolute;top:"+marginObj[inx+1]+"px'>"+temphtml+"<a href="+link+" target='_blank' class='' >"+title+"</a></p>"

	      if(inx==9){
	        $short_log.html("<ul class='list-group'><li  class='issue_list_wrap list-group-item' style='border:1px solid #17A91E'>"+shortInnerhtml+"</li></ul>");
	         shortScrollUp('short_log',900);
	      }
	      

	    }); 
	}

	
	var win = chrome.app.window.current();

	



	$('#top').change(function() {
        if($(this).is(":checked")) {
            
            win.setAlwaysOnTop(true);
        }else{
        	
        	win.setAlwaysOnTop(false);
        }
        
    });


	$('#sync').on('click',function(){
		sync();
	});

	$('#close').on('click',function(){
		window.close();
	});

};



chrome.app.window.onBoundsChanged.addListener(run);

onload = run;